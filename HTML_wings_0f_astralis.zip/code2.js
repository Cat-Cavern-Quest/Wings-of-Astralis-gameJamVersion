gdjs.JogoCode = {};
gdjs.JogoCode.localVariables = [];
gdjs.JogoCode.GDJogadorObjects1= [];
gdjs.JogoCode.GDJogadorObjects2= [];
gdjs.JogoCode.GDJogadorObjects3= [];
gdjs.JogoCode.GDJogadorObjects4= [];
gdjs.JogoCode.GDJogadorObjects5= [];
gdjs.JogoCode.GDJogadorObjects6= [];
gdjs.JogoCode.GDJogadorObjects7= [];
gdjs.JogoCode.GDJogadorObjects8= [];
gdjs.JogoCode.GDpBulletObjects1= [];
gdjs.JogoCode.GDpBulletObjects2= [];
gdjs.JogoCode.GDpBulletObjects3= [];
gdjs.JogoCode.GDpBulletObjects4= [];
gdjs.JogoCode.GDpBulletObjects5= [];
gdjs.JogoCode.GDpBulletObjects6= [];
gdjs.JogoCode.GDpBulletObjects7= [];
gdjs.JogoCode.GDpBulletObjects8= [];
gdjs.JogoCode.GDNautolanSpinningBulletObjects1= [];
gdjs.JogoCode.GDNautolanSpinningBulletObjects2= [];
gdjs.JogoCode.GDNautolanSpinningBulletObjects3= [];
gdjs.JogoCode.GDNautolanSpinningBulletObjects4= [];
gdjs.JogoCode.GDNautolanSpinningBulletObjects5= [];
gdjs.JogoCode.GDNautolanSpinningBulletObjects6= [];
gdjs.JogoCode.GDNautolanSpinningBulletObjects7= [];
gdjs.JogoCode.GDNautolanSpinningBulletObjects8= [];
gdjs.JogoCode.GDeBulletObjects1= [];
gdjs.JogoCode.GDeBulletObjects2= [];
gdjs.JogoCode.GDeBulletObjects3= [];
gdjs.JogoCode.GDeBulletObjects4= [];
gdjs.JogoCode.GDeBulletObjects5= [];
gdjs.JogoCode.GDeBulletObjects6= [];
gdjs.JogoCode.GDeBulletObjects7= [];
gdjs.JogoCode.GDeBulletObjects8= [];
gdjs.JogoCode.GDbackgroundObjects1= [];
gdjs.JogoCode.GDbackgroundObjects2= [];
gdjs.JogoCode.GDbackgroundObjects3= [];
gdjs.JogoCode.GDbackgroundObjects4= [];
gdjs.JogoCode.GDbackgroundObjects5= [];
gdjs.JogoCode.GDbackgroundObjects6= [];
gdjs.JogoCode.GDbackgroundObjects7= [];
gdjs.JogoCode.GDbackgroundObjects8= [];
gdjs.JogoCode.GDChefeObjects1= [];
gdjs.JogoCode.GDChefeObjects2= [];
gdjs.JogoCode.GDChefeObjects3= [];
gdjs.JogoCode.GDChefeObjects4= [];
gdjs.JogoCode.GDChefeObjects5= [];
gdjs.JogoCode.GDChefeObjects6= [];
gdjs.JogoCode.GDChefeObjects7= [];
gdjs.JogoCode.GDChefeObjects8= [];
gdjs.JogoCode.GDMainShipRocketObjects1= [];
gdjs.JogoCode.GDMainShipRocketObjects2= [];
gdjs.JogoCode.GDMainShipRocketObjects3= [];
gdjs.JogoCode.GDMainShipRocketObjects4= [];
gdjs.JogoCode.GDMainShipRocketObjects5= [];
gdjs.JogoCode.GDMainShipRocketObjects6= [];
gdjs.JogoCode.GDMainShipRocketObjects7= [];
gdjs.JogoCode.GDMainShipRocketObjects8= [];
gdjs.JogoCode.GDMainShipAutoCannonBulletObjects1= [];
gdjs.JogoCode.GDMainShipAutoCannonBulletObjects2= [];
gdjs.JogoCode.GDMainShipAutoCannonBulletObjects3= [];
gdjs.JogoCode.GDMainShipAutoCannonBulletObjects4= [];
gdjs.JogoCode.GDMainShipAutoCannonBulletObjects5= [];
gdjs.JogoCode.GDMainShipAutoCannonBulletObjects6= [];
gdjs.JogoCode.GDMainShipAutoCannonBulletObjects7= [];
gdjs.JogoCode.GDMainShipAutoCannonBulletObjects8= [];
gdjs.JogoCode.GDExplosion7Objects1= [];
gdjs.JogoCode.GDExplosion7Objects2= [];
gdjs.JogoCode.GDExplosion7Objects3= [];
gdjs.JogoCode.GDExplosion7Objects4= [];
gdjs.JogoCode.GDExplosion7Objects5= [];
gdjs.JogoCode.GDExplosion7Objects6= [];
gdjs.JogoCode.GDExplosion7Objects7= [];
gdjs.JogoCode.GDExplosion7Objects8= [];
gdjs.JogoCode.GDTop_9595rightObjects1= [];
gdjs.JogoCode.GDTop_9595rightObjects2= [];
gdjs.JogoCode.GDTop_9595rightObjects3= [];
gdjs.JogoCode.GDTop_9595rightObjects4= [];
gdjs.JogoCode.GDTop_9595rightObjects5= [];
gdjs.JogoCode.GDTop_9595rightObjects6= [];
gdjs.JogoCode.GDTop_9595rightObjects7= [];
gdjs.JogoCode.GDTop_9595rightObjects8= [];
gdjs.JogoCode.GDTop_9595LeftObjects1= [];
gdjs.JogoCode.GDTop_9595LeftObjects2= [];
gdjs.JogoCode.GDTop_9595LeftObjects3= [];
gdjs.JogoCode.GDTop_9595LeftObjects4= [];
gdjs.JogoCode.GDTop_9595LeftObjects5= [];
gdjs.JogoCode.GDTop_9595LeftObjects6= [];
gdjs.JogoCode.GDTop_9595LeftObjects7= [];
gdjs.JogoCode.GDTop_9595LeftObjects8= [];
gdjs.JogoCode.GDTop_9595CenterObjects1= [];
gdjs.JogoCode.GDTop_9595CenterObjects2= [];
gdjs.JogoCode.GDTop_9595CenterObjects3= [];
gdjs.JogoCode.GDTop_9595CenterObjects4= [];
gdjs.JogoCode.GDTop_9595CenterObjects5= [];
gdjs.JogoCode.GDTop_9595CenterObjects6= [];
gdjs.JogoCode.GDTop_9595CenterObjects7= [];
gdjs.JogoCode.GDTop_9595CenterObjects8= [];
gdjs.JogoCode.GDBoss_9595HealthObjects1= [];
gdjs.JogoCode.GDBoss_9595HealthObjects2= [];
gdjs.JogoCode.GDBoss_9595HealthObjects3= [];
gdjs.JogoCode.GDBoss_9595HealthObjects4= [];
gdjs.JogoCode.GDBoss_9595HealthObjects5= [];
gdjs.JogoCode.GDBoss_9595HealthObjects6= [];
gdjs.JogoCode.GDBoss_9595HealthObjects7= [];
gdjs.JogoCode.GDBoss_9595HealthObjects8= [];
gdjs.JogoCode.GDPlayer_9595HealthObjects1= [];
gdjs.JogoCode.GDPlayer_9595HealthObjects2= [];
gdjs.JogoCode.GDPlayer_9595HealthObjects3= [];
gdjs.JogoCode.GDPlayer_9595HealthObjects4= [];
gdjs.JogoCode.GDPlayer_9595HealthObjects5= [];
gdjs.JogoCode.GDPlayer_9595HealthObjects6= [];
gdjs.JogoCode.GDPlayer_9595HealthObjects7= [];
gdjs.JogoCode.GDPlayer_9595HealthObjects8= [];
gdjs.JogoCode.GDExplosionFxObjects1= [];
gdjs.JogoCode.GDExplosionFxObjects2= [];
gdjs.JogoCode.GDExplosionFxObjects3= [];
gdjs.JogoCode.GDExplosionFxObjects4= [];
gdjs.JogoCode.GDExplosionFxObjects5= [];
gdjs.JogoCode.GDExplosionFxObjects6= [];
gdjs.JogoCode.GDExplosionFxObjects7= [];
gdjs.JogoCode.GDExplosionFxObjects8= [];
gdjs.JogoCode.GDJogador_9595barraObjects1= [];
gdjs.JogoCode.GDJogador_9595barraObjects2= [];
gdjs.JogoCode.GDJogador_9595barraObjects3= [];
gdjs.JogoCode.GDJogador_9595barraObjects4= [];
gdjs.JogoCode.GDJogador_9595barraObjects5= [];
gdjs.JogoCode.GDJogador_9595barraObjects6= [];
gdjs.JogoCode.GDJogador_9595barraObjects7= [];
gdjs.JogoCode.GDJogador_9595barraObjects8= [];
gdjs.JogoCode.GDChefe_9595barraObjects1= [];
gdjs.JogoCode.GDChefe_9595barraObjects2= [];
gdjs.JogoCode.GDChefe_9595barraObjects3= [];
gdjs.JogoCode.GDChefe_9595barraObjects4= [];
gdjs.JogoCode.GDChefe_9595barraObjects5= [];
gdjs.JogoCode.GDChefe_9595barraObjects6= [];
gdjs.JogoCode.GDChefe_9595barraObjects7= [];
gdjs.JogoCode.GDChefe_9595barraObjects8= [];
gdjs.JogoCode.GDStageObjects1= [];
gdjs.JogoCode.GDStageObjects2= [];
gdjs.JogoCode.GDStageObjects3= [];
gdjs.JogoCode.GDStageObjects4= [];
gdjs.JogoCode.GDStageObjects5= [];
gdjs.JogoCode.GDStageObjects6= [];
gdjs.JogoCode.GDStageObjects7= [];
gdjs.JogoCode.GDStageObjects8= [];


gdjs.JogoCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() == 0);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.JogoCode.GDJogadorObjects1, gdjs.JogoCode.GDJogadorObjects2);

{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].returnVariable(gdjs.JogoCode.GDJogadorObjects2[i].getVariables().getFromIndex(2)).setNumber(500 * 0.5);
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].returnVariable(gdjs.JogoCode.GDJogadorObjects2[i].getVariables().getFromIndex(5)).setNumber(20 * 0.4);
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].getBehavior("Health").SetMaxHealthOp(200, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].getBehavior("Health").Heal(1000000, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].returnVariable(gdjs.JogoCode.GDJogadorObjects2[i].getVariables().getFromIndex(3)).setNumber(gdjs.JogoCode.GDJogadorObjects2[i].getVariables().getFromIndex(2).getAsNumber() * 2);
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].returnVariable(gdjs.JogoCode.GDJogadorObjects2[i].getVariables().getFromIndex(4)).setNumber(gdjs.JogoCode.GDJogadorObjects2[i].getVariables().getFromIndex(2).getAsNumber() / 2);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() == 2);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.JogoCode.GDJogadorObjects1, gdjs.JogoCode.GDJogadorObjects2);

{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].returnVariable(gdjs.JogoCode.GDJogadorObjects2[i].getVariables().getFromIndex(2)).setNumber(500);
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].returnVariable(gdjs.JogoCode.GDJogadorObjects2[i].getVariables().getFromIndex(5)).setNumber(20 * 0.5);
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].getBehavior("Health").SetMaxHealthOp(200 * 0.3, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].getBehavior("Health").Heal(1000000, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].returnVariable(gdjs.JogoCode.GDJogadorObjects2[i].getVariables().getFromIndex(3)).setNumber(gdjs.JogoCode.GDJogadorObjects2[i].getVariables().getFromIndex(2).getAsNumber() * 2);
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].returnVariable(gdjs.JogoCode.GDJogadorObjects2[i].getVariables().getFromIndex(4)).setNumber(gdjs.JogoCode.GDJogadorObjects2[i].getVariables().getFromIndex(2).getAsNumber() / 2);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() == 4);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.JogoCode.GDJogadorObjects1, gdjs.JogoCode.GDJogadorObjects2);

{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].returnVariable(gdjs.JogoCode.GDJogadorObjects2[i].getVariables().getFromIndex(2)).setNumber(500 * 0.3);
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].returnVariable(gdjs.JogoCode.GDJogadorObjects2[i].getVariables().getFromIndex(5)).setNumber(20);
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].getBehavior("Health").SetMaxHealthOp(200 * 0.6, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].getBehavior("Health").Heal(1000000, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].returnVariable(gdjs.JogoCode.GDJogadorObjects2[i].getVariables().getFromIndex(3)).setNumber(gdjs.JogoCode.GDJogadorObjects2[i].getVariables().getFromIndex(2).getAsNumber() * 2);
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].returnVariable(gdjs.JogoCode.GDJogadorObjects2[i].getVariables().getFromIndex(4)).setNumber(gdjs.JogoCode.GDJogadorObjects2[i].getVariables().getFromIndex(2).getAsNumber() / 2);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() == 6);
}
if (isConditionTrue_0) {
/* Reuse gdjs.JogoCode.GDJogadorObjects1 */
{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects1.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects1[i].returnVariable(gdjs.JogoCode.GDJogadorObjects1[i].getVariables().getFromIndex(2)).setNumber(500 * 0.7);
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects1.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects1[i].returnVariable(gdjs.JogoCode.GDJogadorObjects1[i].getVariables().getFromIndex(5)).setNumber(20 * 0.7);
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects1.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects1[i].getBehavior("Health").SetMaxHealthOp(200 * 0.7, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects1.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects1[i].getBehavior("Health").Heal(1000000, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects1.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects1[i].returnVariable(gdjs.JogoCode.GDJogadorObjects1[i].getVariables().getFromIndex(3)).setNumber(gdjs.JogoCode.GDJogadorObjects1[i].getVariables().getFromIndex(2).getAsNumber() * 2);
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects1.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects1[i].returnVariable(gdjs.JogoCode.GDJogadorObjects1[i].getVariables().getFromIndex(4)).setNumber(gdjs.JogoCode.GDJogadorObjects1[i].getVariables().getFromIndex(2).getAsNumber() / 2);
}
}}

}


};gdjs.JogoCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Chefe"), gdjs.JogoCode.GDChefeObjects2);
gdjs.copyArray(runtimeScene.getObjects("Jogador"), gdjs.JogoCode.GDJogadorObjects2);
gdjs.copyArray(runtimeScene.getObjects("background"), gdjs.JogoCode.GDbackgroundObjects2);
{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].setPosition(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) * 0.5,gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) * 0.91);
}
}{for(var i = 0, len = gdjs.JogoCode.GDChefeObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDChefeObjects2[i].setPosition(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) * 0.5,gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) * 0.19);
}
}{for(var i = 0, len = gdjs.JogoCode.GDbackgroundObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDbackgroundObjects2[i].setPosition(0,0);
}
}{for(var i = 0, len = gdjs.JogoCode.GDChefeObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDChefeObjects2[i].getBehavior("Flippable").flipY(true);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Top_Center"), gdjs.JogoCode.GDTop_9595CenterObjects2);
gdjs.copyArray(runtimeScene.getObjects("Top_Left"), gdjs.JogoCode.GDTop_9595LeftObjects2);
gdjs.copyArray(runtimeScene.getObjects("Top_right"), gdjs.JogoCode.GDTop_9595rightObjects2);
{for(var i = 0, len = gdjs.JogoCode.GDTop_9595LeftObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDTop_9595LeftObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.JogoCode.GDTop_9595CenterObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDTop_9595CenterObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.JogoCode.GDTop_9595rightObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDTop_9595rightObjects2[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() == 0);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "stg_theme008_88pro-loop.ogg", true, 40, 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() == 2);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "stg_theme003_88pro-loop.ogg", true, 40, 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() == 4);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "stg_theme005_88pro-loop.ogg", true, 40, 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() == 6);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "stg_theme006_88pro-loop.ogg", true, 40, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jogador"), gdjs.JogoCode.GDJogadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.JogoCode.GDJogadorObjects1.length;i<l;++i) {
    if ( !(gdjs.JogoCode.GDJogadorObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.JogoCode.GDJogadorObjects1[k] = gdjs.JogoCode.GDJogadorObjects1[i];
        ++k;
    }
}
gdjs.JogoCode.GDJogadorObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11677260);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.JogoCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.JogoCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.JogoCode.eventsList1(runtimeScene);} //End of subevents
}

}


};gdjs.JogoCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Stage"), gdjs.JogoCode.GDStageObjects1);
gdjs.copyArray(runtimeScene.getObjects("background"), gdjs.JogoCode.GDbackgroundObjects1);
{for(var i = 0, len = gdjs.JogoCode.GDbackgroundObjects1.length ;i < len;++i) {
    gdjs.JogoCode.GDbackgroundObjects1[i].setYOffset(gdjs.JogoCode.GDbackgroundObjects1[i].getYOffset() + (-(0.4)));
}
}{for(var i = 0, len = gdjs.JogoCode.GDbackgroundObjects1.length ;i < len;++i) {
    gdjs.JogoCode.GDbackgroundObjects1[i].getBehavior("Resizable").setSize(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene), gdjs.evtTools.window.getGameResolutionHeight(runtimeScene));
}
}{for(var i = 0, len = gdjs.JogoCode.GDStageObjects1.length ;i < len;++i) {
    gdjs.JogoCode.GDStageObjects1[i].getBehavior("Text").setText("Stage " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1))));
}
}}

}


};gdjs.JogoCode.mapOfGDgdjs_9546JogoCode_9546GDpBulletObjects1Objects = Hashtable.newFrom({"pBullet": gdjs.JogoCode.GDpBulletObjects1});
gdjs.JogoCode.mapOfGDgdjs_9546JogoCode_9546GDpBulletObjects1Objects = Hashtable.newFrom({"pBullet": gdjs.JogoCode.GDpBulletObjects1});
gdjs.JogoCode.eventsList4 = function(runtimeScene) {

{

/* Reuse gdjs.JogoCode.GDJogadorObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.JogoCode.GDJogadorObjects1.length;i<l;++i) {
    if ( gdjs.JogoCode.GDJogadorObjects1[i].getBehavior("FireBullet").HasJustFired((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.JogoCode.GDJogadorObjects1[k] = gdjs.JogoCode.GDJogadorObjects1[i];
        ++k;
    }
}
gdjs.JogoCode.GDJogadorObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "shoot-2.wav", false, 60, gdjs.randomInRange(0.8, 1.2));
}}

}


};gdjs.JogoCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Jogador"), gdjs.JogoCode.GDJogadorObjects2);
{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].getBehavior("Animation").setAnimationIndex(1 + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].getBehavior("Flippable").flipX(false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Jogador"), gdjs.JogoCode.GDJogadorObjects2);
{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].getBehavior("Animation").setAnimationIndex(1 + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].getBehavior("Flippable").flipX(true);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Jogador"), gdjs.JogoCode.GDJogadorObjects2);
{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Jogador"), gdjs.JogoCode.GDJogadorObjects2);
{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jogador"), gdjs.JogoCode.GDJogadorObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.JogoCode.GDJogadorObjects2.length;i<l;++i) {
    if ( !(gdjs.JogoCode.GDJogadorObjects2[i].getBehavior("TopDownMovement").isUsingControl("Left")) ) {
        isConditionTrue_1 = true;
        gdjs.JogoCode.GDJogadorObjects2[k] = gdjs.JogoCode.GDJogadorObjects2[i];
        ++k;
    }
}
gdjs.JogoCode.GDJogadorObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.JogoCode.GDJogadorObjects2.length;i<l;++i) {
    if ( !(gdjs.JogoCode.GDJogadorObjects2[i].getBehavior("TopDownMovement").isUsingControl("Right")) ) {
        isConditionTrue_1 = true;
        gdjs.JogoCode.GDJogadorObjects2[k] = gdjs.JogoCode.GDJogadorObjects2[i];
        ++k;
    }
}
gdjs.JogoCode.GDJogadorObjects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.JogoCode.GDJogadorObjects2 */
{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].getBehavior("Flippable").flipX(false);
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].getBehavior("Animation").setAnimationIndex(0 + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "z");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Jogador"), gdjs.JogoCode.GDJogadorObjects1);
gdjs.copyArray(runtimeScene.getObjects("pBullet"), gdjs.JogoCode.GDpBulletObjects1);
{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects1.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects1[i].returnVariable(gdjs.JogoCode.GDJogadorObjects1[i].getVariables().getFromIndex(0)).setNumber((gdjs.JogoCode.GDJogadorObjects1[i].getPointX("Gunpoint1")));
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects1.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects1[i].returnVariable(gdjs.JogoCode.GDJogadorObjects1[i].getVariables().getFromIndex(1)).setNumber((gdjs.JogoCode.GDJogadorObjects1[i].getPointY("Gunpoint1")));
}
}{for(var i = 0, len = gdjs.JogoCode.GDpBulletObjects1.length ;i < len;++i) {
    gdjs.JogoCode.GDpBulletObjects1[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects1.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects1[i].getBehavior("FireBullet").Fire((gdjs.RuntimeObject.getVariableNumber(gdjs.JogoCode.GDJogadorObjects1[i].getVariables().getFromIndex(0))), (gdjs.RuntimeObject.getVariableNumber(gdjs.JogoCode.GDJogadorObjects1[i].getVariables().getFromIndex(1))), gdjs.JogoCode.mapOfGDgdjs_9546JogoCode_9546GDpBulletObjects1Objects, -(90), 120, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects1.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects1[i].returnVariable(gdjs.JogoCode.GDJogadorObjects1[i].getVariables().getFromIndex(0)).setNumber((gdjs.JogoCode.GDJogadorObjects1[i].getPointX("Gunpoint2")));
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects1.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects1[i].returnVariable(gdjs.JogoCode.GDJogadorObjects1[i].getVariables().getFromIndex(1)).setNumber((gdjs.JogoCode.GDJogadorObjects1[i].getPointY("Gunpoint2")));
}
}{for(var i = 0, len = gdjs.JogoCode.GDpBulletObjects1.length ;i < len;++i) {
    gdjs.JogoCode.GDpBulletObjects1[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects1.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects1[i].getBehavior("FireBullet").Fire((gdjs.RuntimeObject.getVariableNumber(gdjs.JogoCode.GDJogadorObjects1[i].getVariables().getFromIndex(0))), (gdjs.RuntimeObject.getVariableNumber(gdjs.JogoCode.GDJogadorObjects1[i].getVariables().getFromIndex(1))), gdjs.JogoCode.mapOfGDgdjs_9546JogoCode_9546GDpBulletObjects1Objects, -(90), 120, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.JogoCode.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs.JogoCode.mapOfGDgdjs_9546JogoCode_9546GDJogadorObjects2Objects = Hashtable.newFrom({"Jogador": gdjs.JogoCode.GDJogadorObjects2});
gdjs.JogoCode.mapOfGDgdjs_9546JogoCode_9546GDChefeObjects2Objects = Hashtable.newFrom({"Chefe": gdjs.JogoCode.GDChefeObjects2});
gdjs.JogoCode.mapOfGDgdjs_9546JogoCode_9546GDExplosionFxObjects2Objects = Hashtable.newFrom({"ExplosionFx": gdjs.JogoCode.GDExplosionFxObjects2});
gdjs.JogoCode.asyncCallback10309572 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.JogoCode.localVariables);
gdjs.JogoCode.localVariables.length = 0;
}
gdjs.JogoCode.eventsList6 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.JogoCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.JogoCode.asyncCallback10309572(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.JogoCode.asyncCallback12967076 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.JogoCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Gameover", false);
}gdjs.JogoCode.localVariables.length = 0;
}
gdjs.JogoCode.eventsList7 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.JogoCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.JogoCode.asyncCallback12967076(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.JogoCode.mapOfGDgdjs_9546JogoCode_9546GDeBulletObjects2Objects = Hashtable.newFrom({"eBullet": gdjs.JogoCode.GDeBulletObjects2});
gdjs.JogoCode.mapOfGDgdjs_9546JogoCode_9546GDJogadorObjects2Objects = Hashtable.newFrom({"Jogador": gdjs.JogoCode.GDJogadorObjects2});
gdjs.JogoCode.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Jogador"), gdjs.JogoCode.GDJogadorObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.JogoCode.GDJogadorObjects2.length;i<l;++i) {
    if ( !(gdjs.JogoCode.GDJogadorObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.JogoCode.GDJogadorObjects2[k] = gdjs.JogoCode.GDJogadorObjects2[i];
        ++k;
    }
}
gdjs.JogoCode.GDJogadorObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.JogoCode.GDJogadorObjects2 */
{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].getBehavior("TopDownMovement").setAcceleration(gdjs.JogoCode.GDJogadorObjects2[i].getVariables().getFromIndex(2).getAsNumber());
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].getBehavior("TopDownMovement").setDeceleration(gdjs.JogoCode.GDJogadorObjects2[i].getVariables().getFromIndex(3).getAsNumber());
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].getBehavior("TopDownMovement").setMaxSpeed(gdjs.JogoCode.GDJogadorObjects2[i].getVariables().getFromIndex(4).getAsNumber());
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Chefe"), gdjs.JogoCode.GDChefeObjects2);
gdjs.copyArray(runtimeScene.getObjects("Jogador"), gdjs.JogoCode.GDJogadorObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.JogoCode.mapOfGDgdjs_9546JogoCode_9546GDJogadorObjects2Objects, gdjs.JogoCode.mapOfGDgdjs_9546JogoCode_9546GDChefeObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.JogoCode.GDChefeObjects2 */
/* Reuse gdjs.JogoCode.GDJogadorObjects2 */
{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].addPolarForce(-(((gdjs.JogoCode.GDJogadorObjects2[i].getAngleToObject((gdjs.JogoCode.GDChefeObjects2.length !== 0 ? gdjs.JogoCode.GDChefeObjects2[0] : null))))), 800, 0);
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].getBehavior("Health").Hit(gdjs.JogoCode.GDJogadorObjects2[i].getVariables().getFromIndex(5).getAsNumber(), true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jogador"), gdjs.JogoCode.GDJogadorObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.JogoCode.GDJogadorObjects2.length;i<l;++i) {
    if ( gdjs.JogoCode.GDJogadorObjects2[i].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.JogoCode.GDJogadorObjects2[k] = gdjs.JogoCode.GDJogadorObjects2[i];
        ++k;
    }
}
gdjs.JogoCode.GDJogadorObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(13023260);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.JogoCode.GDJogadorObjects2 */
gdjs.JogoCode.GDExplosionFxObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.JogoCode.mapOfGDgdjs_9546JogoCode_9546GDExplosionFxObjects2Objects, (( gdjs.JogoCode.GDJogadorObjects2.length === 0 ) ? 0 :gdjs.JogoCode.GDJogadorObjects2[0].getPointX("")), (( gdjs.JogoCode.GDJogadorObjects2.length === 0 ) ? 0 :gdjs.JogoCode.GDJogadorObjects2[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.JogoCode.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("ExplosionFx"), gdjs.JogoCode.GDExplosionFxObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.JogoCode.GDExplosionFxObjects2.length;i<l;++i) {
    if ( gdjs.JogoCode.GDExplosionFxObjects2[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.JogoCode.GDExplosionFxObjects2[k] = gdjs.JogoCode.GDExplosionFxObjects2[i];
        ++k;
    }
}
gdjs.JogoCode.GDExplosionFxObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.JogoCode.GDExplosionFxObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Jogador"), gdjs.JogoCode.GDJogadorObjects2);
{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.JogoCode.GDExplosionFxObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDExplosionFxObjects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.JogoCode.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Jogador"), gdjs.JogoCode.GDJogadorObjects2);
gdjs.copyArray(runtimeScene.getObjects("eBullet"), gdjs.JogoCode.GDeBulletObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.JogoCode.mapOfGDgdjs_9546JogoCode_9546GDeBulletObjects2Objects, gdjs.JogoCode.mapOfGDgdjs_9546JogoCode_9546GDJogadorObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.JogoCode.GDeBulletObjects2 */
{for(var i = 0, len = gdjs.JogoCode.GDeBulletObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDeBulletObjects2[i].getBehavior("Animation").setAnimationIndex(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("eBullet"), gdjs.JogoCode.GDeBulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.JogoCode.GDeBulletObjects1.length;i<l;++i) {
    if ( gdjs.JogoCode.GDeBulletObjects1[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.JogoCode.GDeBulletObjects1[k] = gdjs.JogoCode.GDeBulletObjects1[i];
        ++k;
    }
}
gdjs.JogoCode.GDeBulletObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Jogador"), gdjs.JogoCode.GDJogadorObjects1);
/* Reuse gdjs.JogoCode.GDeBulletObjects1 */
{for(var i = 0, len = gdjs.JogoCode.GDJogadorObjects1.length ;i < len;++i) {
    gdjs.JogoCode.GDJogadorObjects1[i].getBehavior("Health").Hit(15, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.JogoCode.GDeBulletObjects1.length ;i < len;++i) {
    gdjs.JogoCode.GDeBulletObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.JogoCode.mapOfGDgdjs_9546JogoCode_9546GDExplosion7Objects2Objects = Hashtable.newFrom({"Explosion7": gdjs.JogoCode.GDExplosion7Objects2});
gdjs.JogoCode.mapOfGDgdjs_9546JogoCode_9546GDpBulletObjects2Objects = Hashtable.newFrom({"pBullet": gdjs.JogoCode.GDpBulletObjects2});
gdjs.JogoCode.mapOfGDgdjs_9546JogoCode_9546GDChefeObjects2Objects = Hashtable.newFrom({"Chefe": gdjs.JogoCode.GDChefeObjects2});
gdjs.JogoCode.eventsList9 = function(runtimeScene) {

{

/* Reuse gdjs.JogoCode.GDpBulletObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.JogoCode.GDpBulletObjects2.length;i<l;++i) {
    if ( gdjs.JogoCode.GDpBulletObjects2[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.JogoCode.GDpBulletObjects2[k] = gdjs.JogoCode.GDpBulletObjects2[i];
        ++k;
    }
}
gdjs.JogoCode.GDpBulletObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.JogoCode.GDChefeObjects2 */
/* Reuse gdjs.JogoCode.GDpBulletObjects2 */
{for(var i = 0, len = gdjs.JogoCode.GDChefeObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDChefeObjects2[i].getBehavior("Health").Hit(15, true, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.JogoCode.GDpBulletObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDpBulletObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.JogoCode.mapOfGDgdjs_9546JogoCode_9546GDChefeObjects3Objects = Hashtable.newFrom({"Chefe": gdjs.JogoCode.GDChefeObjects3});
gdjs.JogoCode.eventsList10 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12030276);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(1).add(1);
}}

}


};gdjs.JogoCode.asyncCallback10071820 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.JogoCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Chefe"), gdjs.JogoCode.GDChefeObjects3);

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.JogoCode.mapOfGDgdjs_9546JogoCode_9546GDChefeObjects3Objects, gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) * 0.5, gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) * 0.19, "");
}{for(var i = 0, len = gdjs.JogoCode.GDChefeObjects3.length ;i < len;++i) {
    gdjs.JogoCode.GDChefeObjects3[i].getBehavior("Flippable").flipY(true);
}
}
{ //Subevents
gdjs.JogoCode.eventsList10(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.JogoCode.localVariables.length = 0;
}
gdjs.JogoCode.eventsList11 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.JogoCode.localVariables);
for (const obj of gdjs.JogoCode.GDChefeObjects2) asyncObjectsList.addObject("Chefe", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3), (runtimeScene) => (gdjs.JogoCode.asyncCallback10071820(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.JogoCode.asyncCallback16261652 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.JogoCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Chefe"), gdjs.JogoCode.GDChefeObjects8);

{for(var i = 0, len = gdjs.JogoCode.GDChefeObjects8.length ;i < len;++i) {
    gdjs.JogoCode.GDChefeObjects8[i].returnVariable(gdjs.JogoCode.GDChefeObjects8[i].getVariables().getFromIndex(0)).setNumber(0);
}
}gdjs.JogoCode.localVariables.length = 0;
}
gdjs.JogoCode.eventsList12 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.JogoCode.localVariables);
for (const obj of gdjs.JogoCode.GDChefeObjects7) asyncObjectsList.addObject("Chefe", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.1), (runtimeScene) => (gdjs.JogoCode.asyncCallback16261652(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.JogoCode.asyncCallback9789212 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.JogoCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Chefe"), gdjs.JogoCode.GDChefeObjects7);

gdjs.copyArray(runtimeScene.getObjects("Top_Center"), gdjs.JogoCode.GDTop_9595CenterObjects7);
{for(var i = 0, len = gdjs.JogoCode.GDChefeObjects7.length ;i < len;++i) {
    gdjs.JogoCode.GDChefeObjects7[i].getBehavior("Tween").addObjectPositionXTween2("part3", (( gdjs.JogoCode.GDTop_9595CenterObjects7.length === 0 ) ? 0 :gdjs.JogoCode.GDTop_9595CenterObjects7[0].getPointX("")), "easeInOutQuad", 1.5, false);
}
}
{ //Subevents
gdjs.JogoCode.eventsList12(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.JogoCode.localVariables.length = 0;
}
gdjs.JogoCode.eventsList13 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(gdjs.JogoCode.localVariables);
for (const obj of gdjs.JogoCode.GDChefeObjects6) asyncObjectsList.addObject("Chefe", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(3.1), (runtimeScene) => (gdjs.JogoCode.asyncCallback9789212(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.JogoCode.asyncCallback16028700 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.JogoCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("Chefe"), gdjs.JogoCode.GDChefeObjects6);

gdjs.copyArray(runtimeScene.getObjects("Top_right"), gdjs.JogoCode.GDTop_9595rightObjects6);
{for(var i = 0, len = gdjs.JogoCode.GDChefeObjects6.length ;i < len;++i) {
    gdjs.JogoCode.GDChefeObjects6[i].getBehavior("Tween").addObjectPositionXTween2("part2", (( gdjs.JogoCode.GDTop_9595rightObjects6.length === 0 ) ? 0 :gdjs.JogoCode.GDTop_9595rightObjects6[0].getPointX("")), "easeInOutQuad", 4, false);
}
}
{ //Subevents
gdjs.JogoCode.eventsList13(runtimeScene, asyncObjectsList);} //End of subevents
gdjs.JogoCode.localVariables.length = 0;
}
gdjs.JogoCode.eventsList14 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.JogoCode.localVariables);
for (const obj of gdjs.JogoCode.GDChefeObjects5) asyncObjectsList.addObject("Chefe", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.1), (runtimeScene) => (gdjs.JogoCode.asyncCallback16028700(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.JogoCode.mapOfGDgdjs_9546JogoCode_9546GDeBulletObjects4Objects = Hashtable.newFrom({"eBullet": gdjs.JogoCode.GDeBulletObjects4});
gdjs.JogoCode.mapOfGDgdjs_9546JogoCode_9546GDeBulletObjects4Objects = Hashtable.newFrom({"eBullet": gdjs.JogoCode.GDeBulletObjects4});
gdjs.JogoCode.eventsList15 = function(runtimeScene) {

{

/* Reuse gdjs.JogoCode.GDChefeObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.JogoCode.GDChefeObjects4.length;i<l;++i) {
    if ( gdjs.JogoCode.GDChefeObjects4[i].getBehavior("FireBullet").HasJustFired((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.JogoCode.GDChefeObjects4[k] = gdjs.JogoCode.GDChefeObjects4[i];
        ++k;
    }
}
gdjs.JogoCode.GDChefeObjects4.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "shoot-2.wav", false, 50, gdjs.randomInRange(1.4, 18));
}}

}


};gdjs.JogoCode.eventsList16 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(8899420);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.JogoCode.GDChefeObjects4, gdjs.JogoCode.GDChefeObjects5);

gdjs.copyArray(runtimeScene.getObjects("Top_Left"), gdjs.JogoCode.GDTop_9595LeftObjects5);
{for(var i = 0, len = gdjs.JogoCode.GDChefeObjects5.length ;i < len;++i) {
    gdjs.JogoCode.GDChefeObjects5[i].getBehavior("Tween").addObjectPositionXTween2("part1", (( gdjs.JogoCode.GDTop_9595LeftObjects5.length === 0 ) ? 0 :gdjs.JogoCode.GDTop_9595LeftObjects5[0].getPointX("")), "easeInOutQuad", 1.5, false);
}
}
{ //Subevents
gdjs.JogoCode.eventsList14(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.JogoCode.GDChefeObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.JogoCode.GDChefeObjects4.length;i<l;++i) {
    if ( gdjs.JogoCode.GDChefeObjects4[i].getBehavior("Tween").isPlaying("part2") ) {
        isConditionTrue_0 = true;
        gdjs.JogoCode.GDChefeObjects4[k] = gdjs.JogoCode.GDChefeObjects4[i];
        ++k;
    }
}
gdjs.JogoCode.GDChefeObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.JogoCode.GDChefeObjects4 */
gdjs.copyArray(runtimeScene.getObjects("eBullet"), gdjs.JogoCode.GDeBulletObjects4);
{for(var i = 0, len = gdjs.JogoCode.GDeBulletObjects4.length ;i < len;++i) {
    gdjs.JogoCode.GDeBulletObjects4[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.JogoCode.GDChefeObjects4.length ;i < len;++i) {
    gdjs.JogoCode.GDChefeObjects4[i].getBehavior("FireBullet").SetBulletQuantityOp(1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.JogoCode.GDChefeObjects4.length ;i < len;++i) {
    gdjs.JogoCode.GDChefeObjects4[i].getBehavior("FireBullet").Fire((gdjs.JogoCode.GDChefeObjects4[i].getPointX("Gunpoint1")), (gdjs.JogoCode.GDChefeObjects4[i].getPointY("Gunpoint1")), gdjs.JogoCode.mapOfGDgdjs_9546JogoCode_9546GDeBulletObjects4Objects, 120, 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.JogoCode.GDChefeObjects4.length ;i < len;++i) {
    gdjs.JogoCode.GDChefeObjects4[i].getBehavior("FireBullet").Fire((gdjs.JogoCode.GDChefeObjects4[i].getPointX("Gunpoint2")), (gdjs.JogoCode.GDChefeObjects4[i].getPointY("Gunpoint2")), gdjs.JogoCode.mapOfGDgdjs_9546JogoCode_9546GDeBulletObjects4Objects, 50, 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.JogoCode.GDeBulletObjects4.length ;i < len;++i) {
    gdjs.JogoCode.GDeBulletObjects4[i].getBehavior("Scale").setScale(0.8);
}
}
{ //Subevents
gdjs.JogoCode.eventsList15(runtimeScene);} //End of subevents
}

}


};gdjs.JogoCode.mapOfGDgdjs_9546JogoCode_9546GDeBulletObjects4Objects = Hashtable.newFrom({"eBullet": gdjs.JogoCode.GDeBulletObjects4});
gdjs.JogoCode.mapOfGDgdjs_9546JogoCode_9546GDeBulletObjects4Objects = Hashtable.newFrom({"eBullet": gdjs.JogoCode.GDeBulletObjects4});
gdjs.JogoCode.eventsList17 = function(runtimeScene) {

{

/* Reuse gdjs.JogoCode.GDChefeObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.JogoCode.GDChefeObjects4.length;i<l;++i) {
    if ( gdjs.JogoCode.GDChefeObjects4[i].getBehavior("FireBullet").HasJustFired((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.JogoCode.GDChefeObjects4[k] = gdjs.JogoCode.GDChefeObjects4[i];
        ++k;
    }
}
gdjs.JogoCode.GDChefeObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.JogoCode.GDChefeObjects4 */
{gdjs.evtTools.sound.playSound(runtimeScene, "shoot-2.wav", false, 50, gdjs.randomInRange(1.4, 18));
}{for(var i = 0, len = gdjs.JogoCode.GDChefeObjects4.length ;i < len;++i) {
    gdjs.JogoCode.GDChefeObjects4[i].returnVariable(gdjs.JogoCode.GDChefeObjects4[i].getVariables().getFromIndex(0)).setNumber(0);
}
}}

}


};gdjs.JogoCode.eventsList18 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.JogoCode.GDChefeObjects3, gdjs.JogoCode.GDChefeObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.JogoCode.GDChefeObjects4.length;i<l;++i) {
    if ( gdjs.JogoCode.GDChefeObjects4[i].getVariableNumber(gdjs.JogoCode.GDChefeObjects4[i].getVariables().getFromIndex(0)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.JogoCode.GDChefeObjects4[k] = gdjs.JogoCode.GDChefeObjects4[i];
        ++k;
    }
}
gdjs.JogoCode.GDChefeObjects4.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.JogoCode.eventsList16(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(gdjs.JogoCode.GDChefeObjects3, gdjs.JogoCode.GDChefeObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.JogoCode.GDChefeObjects4.length;i<l;++i) {
    if ( gdjs.JogoCode.GDChefeObjects4[i].getVariableNumber(gdjs.JogoCode.GDChefeObjects4[i].getVariables().getFromIndex(0)) == 2 ) {
        isConditionTrue_0 = true;
        gdjs.JogoCode.GDChefeObjects4[k] = gdjs.JogoCode.GDChefeObjects4[i];
        ++k;
    }
}
gdjs.JogoCode.GDChefeObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.JogoCode.GDChefeObjects4 */
gdjs.copyArray(runtimeScene.getObjects("eBullet"), gdjs.JogoCode.GDeBulletObjects4);
{for(var i = 0, len = gdjs.JogoCode.GDeBulletObjects4.length ;i < len;++i) {
    gdjs.JogoCode.GDeBulletObjects4[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.JogoCode.GDChefeObjects4.length ;i < len;++i) {
    gdjs.JogoCode.GDChefeObjects4[i].getBehavior("FireBullet").SetBulletQuantityOp(4, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.JogoCode.GDChefeObjects4.length ;i < len;++i) {
    gdjs.JogoCode.GDChefeObjects4[i].getBehavior("FireBullet").SetFiringArcOp(120, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.JogoCode.GDChefeObjects4.length ;i < len;++i) {
    gdjs.JogoCode.GDChefeObjects4[i].getBehavior("FireBullet").Fire((gdjs.JogoCode.GDChefeObjects4[i].getPointX("Gunpoint1")), (gdjs.JogoCode.GDChefeObjects4[i].getPointY("Gunpoint1")), gdjs.JogoCode.mapOfGDgdjs_9546JogoCode_9546GDeBulletObjects4Objects, 120, 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.JogoCode.GDChefeObjects4.length ;i < len;++i) {
    gdjs.JogoCode.GDChefeObjects4[i].getBehavior("FireBullet").Fire((gdjs.JogoCode.GDChefeObjects4[i].getPointX("Gunpoint2")), (gdjs.JogoCode.GDChefeObjects4[i].getPointY("Gunpoint2")), gdjs.JogoCode.mapOfGDgdjs_9546JogoCode_9546GDeBulletObjects4Objects, 50, 100, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.JogoCode.eventsList17(runtimeScene);} //End of subevents
}

}


{



}


{

/* Reuse gdjs.JogoCode.GDChefeObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.JogoCode.GDChefeObjects3.length;i<l;++i) {
    if ( gdjs.JogoCode.GDChefeObjects3[i].getVariableNumber(gdjs.JogoCode.GDChefeObjects3[i].getVariables().getFromIndex(0)) == 3 ) {
        isConditionTrue_0 = true;
        gdjs.JogoCode.GDChefeObjects3[k] = gdjs.JogoCode.GDChefeObjects3[i];
        ++k;
    }
}
gdjs.JogoCode.GDChefeObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.JogoCode.GDChefeObjects3 */
{for(var i = 0, len = gdjs.JogoCode.GDChefeObjects3.length ;i < len;++i) {
    gdjs.JogoCode.GDChefeObjects3[i].returnVariable(gdjs.JogoCode.GDChefeObjects3[i].getVariables().getFromIndex(0)).setNumber(0);
}
}}

}


};gdjs.JogoCode.eventsList19 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Top_Center"), gdjs.JogoCode.GDTop_9595CenterObjects2);
gdjs.copyArray(runtimeScene.getObjects("Top_Left"), gdjs.JogoCode.GDTop_9595LeftObjects2);
gdjs.copyArray(runtimeScene.getObjects("Top_right"), gdjs.JogoCode.GDTop_9595rightObjects2);
{for(var i = 0, len = gdjs.JogoCode.GDTop_9595rightObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDTop_9595rightObjects2[i].setPosition(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) * 0.98,gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) * 0.05);
}
}{for(var i = 0, len = gdjs.JogoCode.GDTop_9595CenterObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDTop_9595CenterObjects2[i].setPosition(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) * 0.5,gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) * 0.05);
}
}{for(var i = 0, len = gdjs.JogoCode.GDTop_9595LeftObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDTop_9595LeftObjects2[i].setPosition(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) * 0.02,gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) * 0.05);
}
}}

}


};gdjs.JogoCode.eventsList20 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Chefe"), gdjs.JogoCode.GDChefeObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.JogoCode.GDChefeObjects3.length;i<l;++i) {
    if ( gdjs.JogoCode.GDChefeObjects3[i].getVariableNumber(gdjs.JogoCode.GDChefeObjects3[i].getVariables().getFromIndex(0)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.JogoCode.GDChefeObjects3[k] = gdjs.JogoCode.GDChefeObjects3[i];
        ++k;
    }
}
gdjs.JogoCode.GDChefeObjects3.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.JogoCode.eventsList18(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Chefe"), gdjs.JogoCode.GDChefeObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.JogoCode.GDChefeObjects3.length;i<l;++i) {
    if ( gdjs.JogoCode.GDChefeObjects3[i].getVariableNumber(gdjs.JogoCode.GDChefeObjects3[i].getVariables().getFromIndex(0)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.JogoCode.GDChefeObjects3[k] = gdjs.JogoCode.GDChefeObjects3[i];
        ++k;
    }
}
gdjs.JogoCode.GDChefeObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.JogoCode.GDChefeObjects3 */
{for(var i = 0, len = gdjs.JogoCode.GDChefeObjects3.length ;i < len;++i) {
    gdjs.JogoCode.GDChefeObjects3[i].returnVariable(gdjs.JogoCode.GDChefeObjects3[i].getVariables().getFromIndex(0)).setNumber(gdjs.randomInRange(1, gdjs.JogoCode.GDChefeObjects3[i].getVariables().getFromIndex(1).getAsNumber()));
}
}}

}


{


gdjs.JogoCode.eventsList19(runtimeScene);
}


};gdjs.JogoCode.eventsList21 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Chefe"), gdjs.JogoCode.GDChefeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.JogoCode.GDChefeObjects2.length;i<l;++i) {
    if ( gdjs.JogoCode.GDChefeObjects2[i].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.JogoCode.GDChefeObjects2[k] = gdjs.JogoCode.GDChefeObjects2[i];
        ++k;
    }
}
gdjs.JogoCode.GDChefeObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12916732);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.JogoCode.GDChefeObjects2 */
gdjs.JogoCode.GDExplosion7Objects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.JogoCode.mapOfGDgdjs_9546JogoCode_9546GDExplosion7Objects2Objects, (( gdjs.JogoCode.GDChefeObjects2.length === 0 ) ? 0 :gdjs.JogoCode.GDChefeObjects2[0].getPointX("")), (( gdjs.JogoCode.GDChefeObjects2.length === 0 ) ? 0 :gdjs.JogoCode.GDChefeObjects2[0].getPointY("")), "");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Chefe"), gdjs.JogoCode.GDChefeObjects2);
gdjs.copyArray(runtimeScene.getObjects("pBullet"), gdjs.JogoCode.GDpBulletObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.JogoCode.mapOfGDgdjs_9546JogoCode_9546GDpBulletObjects2Objects, gdjs.JogoCode.mapOfGDgdjs_9546JogoCode_9546GDChefeObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.JogoCode.GDpBulletObjects2 */
{for(var i = 0, len = gdjs.JogoCode.GDpBulletObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDpBulletObjects2[i].getBehavior("Animation").setAnimationIndex(1);
}
}
{ //Subevents
gdjs.JogoCode.eventsList9(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Explosion7"), gdjs.JogoCode.GDExplosion7Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.JogoCode.GDExplosion7Objects2.length;i<l;++i) {
    if ( gdjs.JogoCode.GDExplosion7Objects2[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.JogoCode.GDExplosion7Objects2[k] = gdjs.JogoCode.GDExplosion7Objects2[i];
        ++k;
    }
}
gdjs.JogoCode.GDExplosion7Objects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Chefe"), gdjs.JogoCode.GDChefeObjects2);
/* Reuse gdjs.JogoCode.GDExplosion7Objects2 */
{for(var i = 0, len = gdjs.JogoCode.GDChefeObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDChefeObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.JogoCode.GDExplosion7Objects2.length ;i < len;++i) {
    gdjs.JogoCode.GDExplosion7Objects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.JogoCode.eventsList11(runtimeScene);} //End of subevents
}

}


{


gdjs.JogoCode.eventsList20(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Chefe"), gdjs.JogoCode.GDChefeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.JogoCode.GDChefeObjects2.length;i<l;++i) {
    if ( gdjs.JogoCode.GDChefeObjects2[i].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) <= (gdjs.JogoCode.GDChefeObjects2[i].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) * 0.70 ) {
        isConditionTrue_0 = true;
        gdjs.JogoCode.GDChefeObjects2[k] = gdjs.JogoCode.GDChefeObjects2[i];
        ++k;
    }
}
gdjs.JogoCode.GDChefeObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12951636);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.JogoCode.GDChefeObjects2 */
{for(var i = 0, len = gdjs.JogoCode.GDChefeObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDChefeObjects2[i].returnVariable(gdjs.JogoCode.GDChefeObjects2[i].getVariables().getFromIndex(1)).add(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Chefe"), gdjs.JogoCode.GDChefeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.JogoCode.GDChefeObjects2.length;i<l;++i) {
    if ( gdjs.JogoCode.GDChefeObjects2[i].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) <= (gdjs.JogoCode.GDChefeObjects2[i].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) * 0.45 ) {
        isConditionTrue_0 = true;
        gdjs.JogoCode.GDChefeObjects2[k] = gdjs.JogoCode.GDChefeObjects2[i];
        ++k;
    }
}
gdjs.JogoCode.GDChefeObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12968620);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.JogoCode.GDChefeObjects2 */
{for(var i = 0, len = gdjs.JogoCode.GDChefeObjects2.length ;i < len;++i) {
    gdjs.JogoCode.GDChefeObjects2[i].returnVariable(gdjs.JogoCode.GDChefeObjects2[i].getVariables().getFromIndex(1)).add(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Chefe"), gdjs.JogoCode.GDChefeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.JogoCode.GDChefeObjects1.length;i<l;++i) {
    if ( gdjs.JogoCode.GDChefeObjects1[i].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.JogoCode.GDChefeObjects1[k] = gdjs.JogoCode.GDChefeObjects1[i];
        ++k;
    }
}
gdjs.JogoCode.GDChefeObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11425092);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.JogoCode.GDChefeObjects1 */
{for(var i = 0, len = gdjs.JogoCode.GDChefeObjects1.length ;i < len;++i) {
    gdjs.JogoCode.GDChefeObjects1[i].returnVariable(gdjs.JogoCode.GDChefeObjects1[i].getVariables().getFromIndex(1)).add(490);
}
}{for(var i = 0, len = gdjs.JogoCode.GDChefeObjects1.length ;i < len;++i) {
    gdjs.JogoCode.GDChefeObjects1[i].getBehavior("Tween").stopTween("part1", false);
}
}{for(var i = 0, len = gdjs.JogoCode.GDChefeObjects1.length ;i < len;++i) {
    gdjs.JogoCode.GDChefeObjects1[i].getBehavior("Tween").stopTween("part2", false);
}
}{for(var i = 0, len = gdjs.JogoCode.GDChefeObjects1.length ;i < len;++i) {
    gdjs.JogoCode.GDChefeObjects1[i].getBehavior("Tween").stopTween("part3", false);
}
}}

}


};gdjs.JogoCode.eventsList22 = function(runtimeScene) {

{

/* Reuse gdjs.JogoCode.GDChefeObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.JogoCode.GDChefeObjects1.length;i<l;++i) {
    if ( !(gdjs.JogoCode.GDChefeObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.JogoCode.GDChefeObjects1[k] = gdjs.JogoCode.GDChefeObjects1[i];
        ++k;
    }
}
gdjs.JogoCode.GDChefeObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9988300);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.JogoCode.GDChefeObjects1 */
{for(var i = 0, len = gdjs.JogoCode.GDChefeObjects1.length ;i < len;++i) {
    gdjs.JogoCode.GDChefeObjects1[i].getBehavior("Health").SetHealth(100 * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.JogoCode.eventsList23 = function(runtimeScene) {

{


gdjs.JogoCode.eventsList2(runtimeScene);
}


{


gdjs.JogoCode.eventsList3(runtimeScene);
}


{


gdjs.JogoCode.eventsList5(runtimeScene);
}


{


gdjs.JogoCode.eventsList8(runtimeScene);
}


{


gdjs.JogoCode.eventsList21(runtimeScene);
}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Chefe"), gdjs.JogoCode.GDChefeObjects1);
gdjs.copyArray(runtimeScene.getObjects("Chefe_barra"), gdjs.JogoCode.GDChefe_9595barraObjects1);
gdjs.copyArray(runtimeScene.getObjects("Jogador"), gdjs.JogoCode.GDJogadorObjects1);
gdjs.copyArray(runtimeScene.getObjects("Jogador_barra"), gdjs.JogoCode.GDJogador_9595barraObjects1);
{for(var i = 0, len = gdjs.JogoCode.GDJogador_9595barraObjects1.length ;i < len;++i) {
    gdjs.JogoCode.GDJogador_9595barraObjects1[i].SetMaxValue((( gdjs.JogoCode.GDJogadorObjects1.length === 0 ) ? 0 :gdjs.JogoCode.GDJogadorObjects1[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.JogoCode.GDChefe_9595barraObjects1.length ;i < len;++i) {
    gdjs.JogoCode.GDChefe_9595barraObjects1[i].SetMaxValue((( gdjs.JogoCode.GDChefeObjects1.length === 0 ) ? 0 :gdjs.JogoCode.GDChefeObjects1[0].getBehavior("Health").MaxHealth((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.JogoCode.GDJogador_9595barraObjects1.length ;i < len;++i) {
    gdjs.JogoCode.GDJogador_9595barraObjects1[i].SetValue((( gdjs.JogoCode.GDJogadorObjects1.length === 0 ) ? 0 :gdjs.JogoCode.GDJogadorObjects1[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.JogoCode.GDChefe_9595barraObjects1.length ;i < len;++i) {
    gdjs.JogoCode.GDChefe_9595barraObjects1[i].SetValue((( gdjs.JogoCode.GDChefeObjects1.length === 0 ) ? 0 :gdjs.JogoCode.GDChefeObjects1[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.JogoCode.GDChefeObjects1.length ;i < len;++i) {
    gdjs.JogoCode.GDChefeObjects1[i].getBehavior("Health").SetMaxHealthOp(100 * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.JogoCode.eventsList22(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("pBullet"), gdjs.JogoCode.GDpBulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.JogoCode.GDpBulletObjects1.length;i<l;++i) {
    if ( !(gdjs.JogoCode.GDpBulletObjects1[i].getBehavior("InOnScreen").IsOnScreen(50, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.JogoCode.GDpBulletObjects1[k] = gdjs.JogoCode.GDpBulletObjects1[i];
        ++k;
    }
}
gdjs.JogoCode.GDpBulletObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.JogoCode.GDpBulletObjects1 */
{for(var i = 0, len = gdjs.JogoCode.GDpBulletObjects1.length ;i < len;++i) {
    gdjs.JogoCode.GDpBulletObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("eBullet"), gdjs.JogoCode.GDeBulletObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.JogoCode.GDeBulletObjects1.length;i<l;++i) {
    if ( !(gdjs.JogoCode.GDeBulletObjects1[i].getBehavior("InOnScreen").IsOnScreen(50, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.JogoCode.GDeBulletObjects1[k] = gdjs.JogoCode.GDeBulletObjects1[i];
        ++k;
    }
}
gdjs.JogoCode.GDeBulletObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.JogoCode.GDeBulletObjects1 */
{for(var i = 0, len = gdjs.JogoCode.GDeBulletObjects1.length ;i < len;++i) {
    gdjs.JogoCode.GDeBulletObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};

gdjs.JogoCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.JogoCode.GDJogadorObjects1.length = 0;
gdjs.JogoCode.GDJogadorObjects2.length = 0;
gdjs.JogoCode.GDJogadorObjects3.length = 0;
gdjs.JogoCode.GDJogadorObjects4.length = 0;
gdjs.JogoCode.GDJogadorObjects5.length = 0;
gdjs.JogoCode.GDJogadorObjects6.length = 0;
gdjs.JogoCode.GDJogadorObjects7.length = 0;
gdjs.JogoCode.GDJogadorObjects8.length = 0;
gdjs.JogoCode.GDpBulletObjects1.length = 0;
gdjs.JogoCode.GDpBulletObjects2.length = 0;
gdjs.JogoCode.GDpBulletObjects3.length = 0;
gdjs.JogoCode.GDpBulletObjects4.length = 0;
gdjs.JogoCode.GDpBulletObjects5.length = 0;
gdjs.JogoCode.GDpBulletObjects6.length = 0;
gdjs.JogoCode.GDpBulletObjects7.length = 0;
gdjs.JogoCode.GDpBulletObjects8.length = 0;
gdjs.JogoCode.GDNautolanSpinningBulletObjects1.length = 0;
gdjs.JogoCode.GDNautolanSpinningBulletObjects2.length = 0;
gdjs.JogoCode.GDNautolanSpinningBulletObjects3.length = 0;
gdjs.JogoCode.GDNautolanSpinningBulletObjects4.length = 0;
gdjs.JogoCode.GDNautolanSpinningBulletObjects5.length = 0;
gdjs.JogoCode.GDNautolanSpinningBulletObjects6.length = 0;
gdjs.JogoCode.GDNautolanSpinningBulletObjects7.length = 0;
gdjs.JogoCode.GDNautolanSpinningBulletObjects8.length = 0;
gdjs.JogoCode.GDeBulletObjects1.length = 0;
gdjs.JogoCode.GDeBulletObjects2.length = 0;
gdjs.JogoCode.GDeBulletObjects3.length = 0;
gdjs.JogoCode.GDeBulletObjects4.length = 0;
gdjs.JogoCode.GDeBulletObjects5.length = 0;
gdjs.JogoCode.GDeBulletObjects6.length = 0;
gdjs.JogoCode.GDeBulletObjects7.length = 0;
gdjs.JogoCode.GDeBulletObjects8.length = 0;
gdjs.JogoCode.GDbackgroundObjects1.length = 0;
gdjs.JogoCode.GDbackgroundObjects2.length = 0;
gdjs.JogoCode.GDbackgroundObjects3.length = 0;
gdjs.JogoCode.GDbackgroundObjects4.length = 0;
gdjs.JogoCode.GDbackgroundObjects5.length = 0;
gdjs.JogoCode.GDbackgroundObjects6.length = 0;
gdjs.JogoCode.GDbackgroundObjects7.length = 0;
gdjs.JogoCode.GDbackgroundObjects8.length = 0;
gdjs.JogoCode.GDChefeObjects1.length = 0;
gdjs.JogoCode.GDChefeObjects2.length = 0;
gdjs.JogoCode.GDChefeObjects3.length = 0;
gdjs.JogoCode.GDChefeObjects4.length = 0;
gdjs.JogoCode.GDChefeObjects5.length = 0;
gdjs.JogoCode.GDChefeObjects6.length = 0;
gdjs.JogoCode.GDChefeObjects7.length = 0;
gdjs.JogoCode.GDChefeObjects8.length = 0;
gdjs.JogoCode.GDMainShipRocketObjects1.length = 0;
gdjs.JogoCode.GDMainShipRocketObjects2.length = 0;
gdjs.JogoCode.GDMainShipRocketObjects3.length = 0;
gdjs.JogoCode.GDMainShipRocketObjects4.length = 0;
gdjs.JogoCode.GDMainShipRocketObjects5.length = 0;
gdjs.JogoCode.GDMainShipRocketObjects6.length = 0;
gdjs.JogoCode.GDMainShipRocketObjects7.length = 0;
gdjs.JogoCode.GDMainShipRocketObjects8.length = 0;
gdjs.JogoCode.GDMainShipAutoCannonBulletObjects1.length = 0;
gdjs.JogoCode.GDMainShipAutoCannonBulletObjects2.length = 0;
gdjs.JogoCode.GDMainShipAutoCannonBulletObjects3.length = 0;
gdjs.JogoCode.GDMainShipAutoCannonBulletObjects4.length = 0;
gdjs.JogoCode.GDMainShipAutoCannonBulletObjects5.length = 0;
gdjs.JogoCode.GDMainShipAutoCannonBulletObjects6.length = 0;
gdjs.JogoCode.GDMainShipAutoCannonBulletObjects7.length = 0;
gdjs.JogoCode.GDMainShipAutoCannonBulletObjects8.length = 0;
gdjs.JogoCode.GDExplosion7Objects1.length = 0;
gdjs.JogoCode.GDExplosion7Objects2.length = 0;
gdjs.JogoCode.GDExplosion7Objects3.length = 0;
gdjs.JogoCode.GDExplosion7Objects4.length = 0;
gdjs.JogoCode.GDExplosion7Objects5.length = 0;
gdjs.JogoCode.GDExplosion7Objects6.length = 0;
gdjs.JogoCode.GDExplosion7Objects7.length = 0;
gdjs.JogoCode.GDExplosion7Objects8.length = 0;
gdjs.JogoCode.GDTop_9595rightObjects1.length = 0;
gdjs.JogoCode.GDTop_9595rightObjects2.length = 0;
gdjs.JogoCode.GDTop_9595rightObjects3.length = 0;
gdjs.JogoCode.GDTop_9595rightObjects4.length = 0;
gdjs.JogoCode.GDTop_9595rightObjects5.length = 0;
gdjs.JogoCode.GDTop_9595rightObjects6.length = 0;
gdjs.JogoCode.GDTop_9595rightObjects7.length = 0;
gdjs.JogoCode.GDTop_9595rightObjects8.length = 0;
gdjs.JogoCode.GDTop_9595LeftObjects1.length = 0;
gdjs.JogoCode.GDTop_9595LeftObjects2.length = 0;
gdjs.JogoCode.GDTop_9595LeftObjects3.length = 0;
gdjs.JogoCode.GDTop_9595LeftObjects4.length = 0;
gdjs.JogoCode.GDTop_9595LeftObjects5.length = 0;
gdjs.JogoCode.GDTop_9595LeftObjects6.length = 0;
gdjs.JogoCode.GDTop_9595LeftObjects7.length = 0;
gdjs.JogoCode.GDTop_9595LeftObjects8.length = 0;
gdjs.JogoCode.GDTop_9595CenterObjects1.length = 0;
gdjs.JogoCode.GDTop_9595CenterObjects2.length = 0;
gdjs.JogoCode.GDTop_9595CenterObjects3.length = 0;
gdjs.JogoCode.GDTop_9595CenterObjects4.length = 0;
gdjs.JogoCode.GDTop_9595CenterObjects5.length = 0;
gdjs.JogoCode.GDTop_9595CenterObjects6.length = 0;
gdjs.JogoCode.GDTop_9595CenterObjects7.length = 0;
gdjs.JogoCode.GDTop_9595CenterObjects8.length = 0;
gdjs.JogoCode.GDBoss_9595HealthObjects1.length = 0;
gdjs.JogoCode.GDBoss_9595HealthObjects2.length = 0;
gdjs.JogoCode.GDBoss_9595HealthObjects3.length = 0;
gdjs.JogoCode.GDBoss_9595HealthObjects4.length = 0;
gdjs.JogoCode.GDBoss_9595HealthObjects5.length = 0;
gdjs.JogoCode.GDBoss_9595HealthObjects6.length = 0;
gdjs.JogoCode.GDBoss_9595HealthObjects7.length = 0;
gdjs.JogoCode.GDBoss_9595HealthObjects8.length = 0;
gdjs.JogoCode.GDPlayer_9595HealthObjects1.length = 0;
gdjs.JogoCode.GDPlayer_9595HealthObjects2.length = 0;
gdjs.JogoCode.GDPlayer_9595HealthObjects3.length = 0;
gdjs.JogoCode.GDPlayer_9595HealthObjects4.length = 0;
gdjs.JogoCode.GDPlayer_9595HealthObjects5.length = 0;
gdjs.JogoCode.GDPlayer_9595HealthObjects6.length = 0;
gdjs.JogoCode.GDPlayer_9595HealthObjects7.length = 0;
gdjs.JogoCode.GDPlayer_9595HealthObjects8.length = 0;
gdjs.JogoCode.GDExplosionFxObjects1.length = 0;
gdjs.JogoCode.GDExplosionFxObjects2.length = 0;
gdjs.JogoCode.GDExplosionFxObjects3.length = 0;
gdjs.JogoCode.GDExplosionFxObjects4.length = 0;
gdjs.JogoCode.GDExplosionFxObjects5.length = 0;
gdjs.JogoCode.GDExplosionFxObjects6.length = 0;
gdjs.JogoCode.GDExplosionFxObjects7.length = 0;
gdjs.JogoCode.GDExplosionFxObjects8.length = 0;
gdjs.JogoCode.GDJogador_9595barraObjects1.length = 0;
gdjs.JogoCode.GDJogador_9595barraObjects2.length = 0;
gdjs.JogoCode.GDJogador_9595barraObjects3.length = 0;
gdjs.JogoCode.GDJogador_9595barraObjects4.length = 0;
gdjs.JogoCode.GDJogador_9595barraObjects5.length = 0;
gdjs.JogoCode.GDJogador_9595barraObjects6.length = 0;
gdjs.JogoCode.GDJogador_9595barraObjects7.length = 0;
gdjs.JogoCode.GDJogador_9595barraObjects8.length = 0;
gdjs.JogoCode.GDChefe_9595barraObjects1.length = 0;
gdjs.JogoCode.GDChefe_9595barraObjects2.length = 0;
gdjs.JogoCode.GDChefe_9595barraObjects3.length = 0;
gdjs.JogoCode.GDChefe_9595barraObjects4.length = 0;
gdjs.JogoCode.GDChefe_9595barraObjects5.length = 0;
gdjs.JogoCode.GDChefe_9595barraObjects6.length = 0;
gdjs.JogoCode.GDChefe_9595barraObjects7.length = 0;
gdjs.JogoCode.GDChefe_9595barraObjects8.length = 0;
gdjs.JogoCode.GDStageObjects1.length = 0;
gdjs.JogoCode.GDStageObjects2.length = 0;
gdjs.JogoCode.GDStageObjects3.length = 0;
gdjs.JogoCode.GDStageObjects4.length = 0;
gdjs.JogoCode.GDStageObjects5.length = 0;
gdjs.JogoCode.GDStageObjects6.length = 0;
gdjs.JogoCode.GDStageObjects7.length = 0;
gdjs.JogoCode.GDStageObjects8.length = 0;

gdjs.JogoCode.eventsList23(runtimeScene);
gdjs.JogoCode.GDJogadorObjects1.length = 0;
gdjs.JogoCode.GDJogadorObjects2.length = 0;
gdjs.JogoCode.GDJogadorObjects3.length = 0;
gdjs.JogoCode.GDJogadorObjects4.length = 0;
gdjs.JogoCode.GDJogadorObjects5.length = 0;
gdjs.JogoCode.GDJogadorObjects6.length = 0;
gdjs.JogoCode.GDJogadorObjects7.length = 0;
gdjs.JogoCode.GDJogadorObjects8.length = 0;
gdjs.JogoCode.GDpBulletObjects1.length = 0;
gdjs.JogoCode.GDpBulletObjects2.length = 0;
gdjs.JogoCode.GDpBulletObjects3.length = 0;
gdjs.JogoCode.GDpBulletObjects4.length = 0;
gdjs.JogoCode.GDpBulletObjects5.length = 0;
gdjs.JogoCode.GDpBulletObjects6.length = 0;
gdjs.JogoCode.GDpBulletObjects7.length = 0;
gdjs.JogoCode.GDpBulletObjects8.length = 0;
gdjs.JogoCode.GDNautolanSpinningBulletObjects1.length = 0;
gdjs.JogoCode.GDNautolanSpinningBulletObjects2.length = 0;
gdjs.JogoCode.GDNautolanSpinningBulletObjects3.length = 0;
gdjs.JogoCode.GDNautolanSpinningBulletObjects4.length = 0;
gdjs.JogoCode.GDNautolanSpinningBulletObjects5.length = 0;
gdjs.JogoCode.GDNautolanSpinningBulletObjects6.length = 0;
gdjs.JogoCode.GDNautolanSpinningBulletObjects7.length = 0;
gdjs.JogoCode.GDNautolanSpinningBulletObjects8.length = 0;
gdjs.JogoCode.GDeBulletObjects1.length = 0;
gdjs.JogoCode.GDeBulletObjects2.length = 0;
gdjs.JogoCode.GDeBulletObjects3.length = 0;
gdjs.JogoCode.GDeBulletObjects4.length = 0;
gdjs.JogoCode.GDeBulletObjects5.length = 0;
gdjs.JogoCode.GDeBulletObjects6.length = 0;
gdjs.JogoCode.GDeBulletObjects7.length = 0;
gdjs.JogoCode.GDeBulletObjects8.length = 0;
gdjs.JogoCode.GDbackgroundObjects1.length = 0;
gdjs.JogoCode.GDbackgroundObjects2.length = 0;
gdjs.JogoCode.GDbackgroundObjects3.length = 0;
gdjs.JogoCode.GDbackgroundObjects4.length = 0;
gdjs.JogoCode.GDbackgroundObjects5.length = 0;
gdjs.JogoCode.GDbackgroundObjects6.length = 0;
gdjs.JogoCode.GDbackgroundObjects7.length = 0;
gdjs.JogoCode.GDbackgroundObjects8.length = 0;
gdjs.JogoCode.GDChefeObjects1.length = 0;
gdjs.JogoCode.GDChefeObjects2.length = 0;
gdjs.JogoCode.GDChefeObjects3.length = 0;
gdjs.JogoCode.GDChefeObjects4.length = 0;
gdjs.JogoCode.GDChefeObjects5.length = 0;
gdjs.JogoCode.GDChefeObjects6.length = 0;
gdjs.JogoCode.GDChefeObjects7.length = 0;
gdjs.JogoCode.GDChefeObjects8.length = 0;
gdjs.JogoCode.GDMainShipRocketObjects1.length = 0;
gdjs.JogoCode.GDMainShipRocketObjects2.length = 0;
gdjs.JogoCode.GDMainShipRocketObjects3.length = 0;
gdjs.JogoCode.GDMainShipRocketObjects4.length = 0;
gdjs.JogoCode.GDMainShipRocketObjects5.length = 0;
gdjs.JogoCode.GDMainShipRocketObjects6.length = 0;
gdjs.JogoCode.GDMainShipRocketObjects7.length = 0;
gdjs.JogoCode.GDMainShipRocketObjects8.length = 0;
gdjs.JogoCode.GDMainShipAutoCannonBulletObjects1.length = 0;
gdjs.JogoCode.GDMainShipAutoCannonBulletObjects2.length = 0;
gdjs.JogoCode.GDMainShipAutoCannonBulletObjects3.length = 0;
gdjs.JogoCode.GDMainShipAutoCannonBulletObjects4.length = 0;
gdjs.JogoCode.GDMainShipAutoCannonBulletObjects5.length = 0;
gdjs.JogoCode.GDMainShipAutoCannonBulletObjects6.length = 0;
gdjs.JogoCode.GDMainShipAutoCannonBulletObjects7.length = 0;
gdjs.JogoCode.GDMainShipAutoCannonBulletObjects8.length = 0;
gdjs.JogoCode.GDExplosion7Objects1.length = 0;
gdjs.JogoCode.GDExplosion7Objects2.length = 0;
gdjs.JogoCode.GDExplosion7Objects3.length = 0;
gdjs.JogoCode.GDExplosion7Objects4.length = 0;
gdjs.JogoCode.GDExplosion7Objects5.length = 0;
gdjs.JogoCode.GDExplosion7Objects6.length = 0;
gdjs.JogoCode.GDExplosion7Objects7.length = 0;
gdjs.JogoCode.GDExplosion7Objects8.length = 0;
gdjs.JogoCode.GDTop_9595rightObjects1.length = 0;
gdjs.JogoCode.GDTop_9595rightObjects2.length = 0;
gdjs.JogoCode.GDTop_9595rightObjects3.length = 0;
gdjs.JogoCode.GDTop_9595rightObjects4.length = 0;
gdjs.JogoCode.GDTop_9595rightObjects5.length = 0;
gdjs.JogoCode.GDTop_9595rightObjects6.length = 0;
gdjs.JogoCode.GDTop_9595rightObjects7.length = 0;
gdjs.JogoCode.GDTop_9595rightObjects8.length = 0;
gdjs.JogoCode.GDTop_9595LeftObjects1.length = 0;
gdjs.JogoCode.GDTop_9595LeftObjects2.length = 0;
gdjs.JogoCode.GDTop_9595LeftObjects3.length = 0;
gdjs.JogoCode.GDTop_9595LeftObjects4.length = 0;
gdjs.JogoCode.GDTop_9595LeftObjects5.length = 0;
gdjs.JogoCode.GDTop_9595LeftObjects6.length = 0;
gdjs.JogoCode.GDTop_9595LeftObjects7.length = 0;
gdjs.JogoCode.GDTop_9595LeftObjects8.length = 0;
gdjs.JogoCode.GDTop_9595CenterObjects1.length = 0;
gdjs.JogoCode.GDTop_9595CenterObjects2.length = 0;
gdjs.JogoCode.GDTop_9595CenterObjects3.length = 0;
gdjs.JogoCode.GDTop_9595CenterObjects4.length = 0;
gdjs.JogoCode.GDTop_9595CenterObjects5.length = 0;
gdjs.JogoCode.GDTop_9595CenterObjects6.length = 0;
gdjs.JogoCode.GDTop_9595CenterObjects7.length = 0;
gdjs.JogoCode.GDTop_9595CenterObjects8.length = 0;
gdjs.JogoCode.GDBoss_9595HealthObjects1.length = 0;
gdjs.JogoCode.GDBoss_9595HealthObjects2.length = 0;
gdjs.JogoCode.GDBoss_9595HealthObjects3.length = 0;
gdjs.JogoCode.GDBoss_9595HealthObjects4.length = 0;
gdjs.JogoCode.GDBoss_9595HealthObjects5.length = 0;
gdjs.JogoCode.GDBoss_9595HealthObjects6.length = 0;
gdjs.JogoCode.GDBoss_9595HealthObjects7.length = 0;
gdjs.JogoCode.GDBoss_9595HealthObjects8.length = 0;
gdjs.JogoCode.GDPlayer_9595HealthObjects1.length = 0;
gdjs.JogoCode.GDPlayer_9595HealthObjects2.length = 0;
gdjs.JogoCode.GDPlayer_9595HealthObjects3.length = 0;
gdjs.JogoCode.GDPlayer_9595HealthObjects4.length = 0;
gdjs.JogoCode.GDPlayer_9595HealthObjects5.length = 0;
gdjs.JogoCode.GDPlayer_9595HealthObjects6.length = 0;
gdjs.JogoCode.GDPlayer_9595HealthObjects7.length = 0;
gdjs.JogoCode.GDPlayer_9595HealthObjects8.length = 0;
gdjs.JogoCode.GDExplosionFxObjects1.length = 0;
gdjs.JogoCode.GDExplosionFxObjects2.length = 0;
gdjs.JogoCode.GDExplosionFxObjects3.length = 0;
gdjs.JogoCode.GDExplosionFxObjects4.length = 0;
gdjs.JogoCode.GDExplosionFxObjects5.length = 0;
gdjs.JogoCode.GDExplosionFxObjects6.length = 0;
gdjs.JogoCode.GDExplosionFxObjects7.length = 0;
gdjs.JogoCode.GDExplosionFxObjects8.length = 0;
gdjs.JogoCode.GDJogador_9595barraObjects1.length = 0;
gdjs.JogoCode.GDJogador_9595barraObjects2.length = 0;
gdjs.JogoCode.GDJogador_9595barraObjects3.length = 0;
gdjs.JogoCode.GDJogador_9595barraObjects4.length = 0;
gdjs.JogoCode.GDJogador_9595barraObjects5.length = 0;
gdjs.JogoCode.GDJogador_9595barraObjects6.length = 0;
gdjs.JogoCode.GDJogador_9595barraObjects7.length = 0;
gdjs.JogoCode.GDJogador_9595barraObjects8.length = 0;
gdjs.JogoCode.GDChefe_9595barraObjects1.length = 0;
gdjs.JogoCode.GDChefe_9595barraObjects2.length = 0;
gdjs.JogoCode.GDChefe_9595barraObjects3.length = 0;
gdjs.JogoCode.GDChefe_9595barraObjects4.length = 0;
gdjs.JogoCode.GDChefe_9595barraObjects5.length = 0;
gdjs.JogoCode.GDChefe_9595barraObjects6.length = 0;
gdjs.JogoCode.GDChefe_9595barraObjects7.length = 0;
gdjs.JogoCode.GDChefe_9595barraObjects8.length = 0;
gdjs.JogoCode.GDStageObjects1.length = 0;
gdjs.JogoCode.GDStageObjects2.length = 0;
gdjs.JogoCode.GDStageObjects3.length = 0;
gdjs.JogoCode.GDStageObjects4.length = 0;
gdjs.JogoCode.GDStageObjects5.length = 0;
gdjs.JogoCode.GDStageObjects6.length = 0;
gdjs.JogoCode.GDStageObjects7.length = 0;
gdjs.JogoCode.GDStageObjects8.length = 0;


return;

}

gdjs['JogoCode'] = gdjs.JogoCode;
